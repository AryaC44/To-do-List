//
//  KlarityApp.swift
//  Klarity
//
//  Created by scholar on 8/15/23.
//

import SwiftUI

@main
struct KlarityApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
